@echo off 
npm i 